import  from ;
export default new ({});
//# sourceMappingURL=main-header.vue.js.map