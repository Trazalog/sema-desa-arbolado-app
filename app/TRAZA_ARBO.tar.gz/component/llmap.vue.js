import  from ;
export default new ({});
//# sourceMappingURL=llmap.vue.js.map