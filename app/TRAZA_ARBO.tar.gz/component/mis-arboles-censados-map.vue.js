import  from ;
export default new ({});
//# sourceMappingURL=mis-arboles-censados-map.vue.js.map